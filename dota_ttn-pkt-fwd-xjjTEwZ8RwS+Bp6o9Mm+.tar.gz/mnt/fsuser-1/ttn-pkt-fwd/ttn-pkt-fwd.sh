#!/bin/sh

BASE="/mnt/fsuser-1/ttn-pkt-fwd"
cd $BASE
killall ttn-pkt-fwd
modem_off.sh

sleep 3
modem_on.sh
sleep 3
export GOGC=30
./ttn-pkt-fwd start --config=config.yml > log.log
