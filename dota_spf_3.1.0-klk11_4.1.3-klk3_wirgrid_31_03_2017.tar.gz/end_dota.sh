#!/bin/sh

# Remove other packet forwarders
rm -rf mnt/fsuser-1/demo_gps_loramote
rm -rf mnt/fsuser-1/packet_forwarder
rm -rf mnt/fsuser-1/kpfd

# Set default configuration file
ln -fs global_conf_new.json ./mnt/fsuser-1/spf/etc/global_conf.json

# Install calibration file
ln -fs /mnt/fsuser-1/loraboard_conf.json ./mnt/fsuser-1/spf/etc/local_conf.json

# Configure syslog
SYSLOG=etc/syslog.conf
mkdir -p ./mnt/fsuser-1/spf/var/log
sed -i '/local1/d' $SYSLOG && printf "local1.*\t/mnt/fsuser-1/spf/var/log/spf.log\n" >> $SYSLOG
